# -*- coding: utf-8 -*-

"""
    pygtkhelpers.ui
    ~~~~~~~~~~~~~~~

    UI Components.

    :copyright: 2005-2010 by pygtkhelpers Authors
    :license: LGPL 2 or later (see README/COPYING/LICENSE)
"""
