
.. automodule:: pygtkhelpers.delegates
    :members:

