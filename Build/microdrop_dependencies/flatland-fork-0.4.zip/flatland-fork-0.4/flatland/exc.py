

class AdaptationError(Exception):
    """A value could not be coerced into native format."""
