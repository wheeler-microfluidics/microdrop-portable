"""
    pygtkheplers.debug
    ~~~~~~~~~~~~~~~~~~

    a library for ui integrated traceback handling in pygtk
"""

from .dialogs import (
        SimpleExceptionDialog,
        install_hook,
        )
