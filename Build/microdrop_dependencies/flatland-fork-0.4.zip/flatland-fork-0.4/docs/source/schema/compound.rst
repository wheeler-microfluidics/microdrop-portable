===============
Compound Fields
===============

.. currentmodule:: flatland

.. autoclass:: Compound
   :show-inheritance:
   :members:

.. autoclass:: DateYYYYMMDD
   :show-inheritance:
   :members:

.. autoclass:: JoinedString
   :show-inheritance:
   :members:
