from ..repository.proxy import PackageRepository


class PluginRepository(PackageRepository):
    repository_name = 'plugins'
