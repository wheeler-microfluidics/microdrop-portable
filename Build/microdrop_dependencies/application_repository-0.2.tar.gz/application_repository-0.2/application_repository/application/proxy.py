from ..repository.proxy import PackageRepository


class AppRepository(PackageRepository):
    repository_name = 'application'
