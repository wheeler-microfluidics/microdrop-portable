
.. automodule:: pygtkhelpers.debug.dialogs
    :members:

