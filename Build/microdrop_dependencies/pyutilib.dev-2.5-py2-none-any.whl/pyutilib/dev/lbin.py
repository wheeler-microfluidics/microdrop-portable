#!/usr/bin/env python

import sys
import os
from os.path import abspath, basename, dirname, exists
import subprocess

def lbin(args):
    if len(args) == 0 or ( args[0] == '-v' and len(args) == 1 ):
        print("usage: lbin [-v] <command> [...]")
        print("This script recurses up the current path, looking for the Acro 'bin' directory.")
        print("If found, this directory is prepended to the PATH environment path.")
        return 1
    
    verbose = False
    if args[0] == '-v':
        verbose = True
        args.pop(0)
    
    pexec = None
    try:
        # On unix, the shell's reported PWD may be different from the '.'
        # inode's absolute path (e.g., when the cwd was reached through
        # symbolic links.)  This is a trivial way to defer to the shell's
        # notion of the cwd and quietly fall back on Python's getcwd() for
        # non-unix environments.
        curr = os.environ['PWD']
    except:
        curr = abspath(os.getcwd())
    dirs = []
    while os.sep in curr:
        if exists(curr+os.sep+"python"):
            dirs.append( curr+os.sep+'python'+os.sep+"bin")
        if exists(curr+os.sep+"bin"):
            dirs.append( curr+os.sep+"bin")
        if basename(curr) == "":
            break
        curr = dirname(curr)
    
    dirs.append(os.environ["PATH"])
    os.environ["PATH"] = os.pathsep.join(dirs)
    try:
        if verbose:
            print("Path search found the following instances of %s:" % args[0])
            x = subprocess.call(['which',args[0]])
            print("")
        return subprocess.call(args)
    except OSError:
        err = sys.exc_info()[1]
        print("ERROR executing command '%s': %s" % (' '.join(args), str(err)))
        return err.errno
    
# The [console_scripts] entry point requires a function that takes no
# arguments
def main():
    sys.exit( lbin( sys.argv[1:] ) )

if __name__ == '__main__':
    main()
