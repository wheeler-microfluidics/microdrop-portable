#  _________________________________________________________________________
#
#  PyUtilib: A Python utility library.
#  Copyright (c) 2008 Sandia Corporation.
#  This software is distributed under the BSD License.
#  Under the terms of Contract DE-AC04-94AL85000 with Sandia Corporation,
#  the U.S. Government retains certain rights in this software.
#  _________________________________________________________________________

import re
import os
import sys
import string
import subprocess
from pyutilib.R.misc_utilities import *

def t_test(x, y=None, mu=0, paired=False, var_equal=False, correct=True,
                conf_level=0.95, alternative=None):
    OUTPUT = open("R_script.R","w")
    #
    # Print 'x'
    #
    OUTPUT.write("x <- c(")
    first=True
    for val in x:
        if not first:
            OUTPUT.write(" , ")
        else:
            first=False
            OUTPUT.write(" ")
        OUTPUT.write(val)
    OUTPUT.write(")\n")
    #
    # Print 'y'
    #
    if y is not None:
        OUTPUT.write("y <- c(")
        first=True
        for val in y:
            if not first:
                OUTPUT.write(" , ")
            else:
                first=False
                OUTPUT.write(" ")
            OUTPUT.write(val)
        OUTPUT.write(")\n")
    #
    # Print command line
    #
    OUTPUT.write("t.test(x,")
    #
    if y is not None:
        OUTPUT.write("y,")
    #
    if not correct:
        OUTPUT.write("correct=FALSE , ")
    else:
        OUTPUT.write("correct=TRUE , ")
    #
    OUTPUT.write("mu="+repr(mu),",")
    #
    #
    if not var_equal:
        OUTPUT.write("var.equal=FALSE ,")
    else:
        OUTPUT.write("var.equal=TRUE ,")
    #
    if not paired:
        OUTPUT.write("paired=FALSE")
    else:
        OUTPUT.write("paired=TRUE")
    #
    OUTPUT.write(")\n")
    OUTPUT.close()
    #
    # Execute R
    #
    cmdout = subprocess.getoutput("R --quiet --vanilla < R_script.R")
    ci_flag=False
    warning_flag=False
    warnings=[]
    ci = None
    pvalue=None
    df=None
    t_statistic=None
    for line in cmdout.split("\n"):
        words = re.split('[ \t]+',line.strip())
        if len(words) == 9 and words[6] == "p-value":
            pvalue= eval(words[8])
            df= eval(words[5].split(",")[0])
            t_statistic = eval(words[2].split(",")[0])
        if ci_flag == True:
            ci = [ eval(words[0]), eval(words[1]) ]
            ci_flag = False
        if len(words) > 2 and words[2] == "confidence":
            ci_flag=True
        if warning_flag:
            warnings.append(line)
        if len(words) > 0 and words[0] == "Warning":
            warning_flag=True
    #
    # Cleanup
    #
    subprocess.getoutput("rm R_script.R")
    return Bunch(conf_int=ci, t=t_statistic, warnings=warnings, df=df, p_value=pvalue)

##
## Launch 'main' if in interactive mode
##
if __name__ == '__main__':
    x = [1,2,3,4,5,6,7,8,9,10]
    print(t_test(x))
    print(t_test(x,x))
