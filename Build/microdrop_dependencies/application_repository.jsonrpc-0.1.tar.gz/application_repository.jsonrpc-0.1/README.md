# `application-repository.jsonrpc` #

This project is a fork of the `python-json-rpc` package hosted [here][1],
written by Jan-Klaas Kollhof.

[1]: http://json-rpc.org/wiki/python-json-rpc
