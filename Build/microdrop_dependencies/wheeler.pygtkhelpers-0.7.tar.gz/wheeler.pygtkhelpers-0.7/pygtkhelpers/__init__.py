# -*- coding: utf-8 -*-

"""
    pygtkhelpers
    ~~~~~~~~~~~~

    Helper library for PyGTK

    :copyright: 2009-2010 by pygtkhelpers Authors
    :license: LGPL2 or later
"""
