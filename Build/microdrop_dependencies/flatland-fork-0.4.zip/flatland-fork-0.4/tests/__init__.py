

# TODO: switch this on with an environ variable or something.
# and document.
#def setup_package():
#    import tests._util
#    tests._util.enable_coercion_blocker()
