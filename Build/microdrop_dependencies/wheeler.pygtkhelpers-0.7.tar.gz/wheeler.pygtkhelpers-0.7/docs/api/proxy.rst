
.. automodule:: pygtkhelpers.proxy
    :members:
    :exclude-members: GObjectProxy

    .. autoclass:: GObjectProxy
        :members: read, update

