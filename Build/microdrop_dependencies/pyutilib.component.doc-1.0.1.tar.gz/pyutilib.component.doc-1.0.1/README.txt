==============================
pyutilib.component.core README
==============================

This package supports documentation for the PyUtilib
Component Architecture.  See `The PyUtilib Component Architecture
<https://software.sandia.gov/svn/public/pyutilib/pyutilib.component.doc/trunk/doc/component/pca.pdf>`_
for a detailed description of PyUtilib components and examples of
their use.

-------
License
-------

BSD.  See the LICENSE.txt file.


------------
Organization
------------

+ Directories

  * pyutilib - The root directory for PyUtilib source code

+ Documentation and Bug Tracking

  * Trac wiki: https://software.sandia.gov/trac/pyutilib

+ Authors

  * See the AUTHORS.txt file.

+ Project Managers

  * William E. Hart, wehart@sandia.gov

+ Mailing List

  * PyUtilib is managed with the Acro Project. A separate checkins mailing
    list is managed for PyUtilib, but otherwise the main Acro mailing lists
    are used to manage the development of this software:

    - acro-developers@software.sandia.gov
    - acro-users@software.sandia.gov

--------------------
Third Party Software
--------------------

None.

